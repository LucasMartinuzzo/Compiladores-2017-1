#ifndef INTERPRETER_H
#define INTERPRETER_H

#include "ast.h"

void run_ast(AST *ast);

#endif
